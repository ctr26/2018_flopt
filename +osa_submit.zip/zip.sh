zip -r +osa_submit.zip ./ -x ".*" -x ".zip"
