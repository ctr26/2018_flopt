zip -r osa_submit.zip ./ -x ".*"
